export interface HighlightMatch {
    node: Node;
    startIndex: number;
    endIndex: number;
    element?: HTMLElement;
}
